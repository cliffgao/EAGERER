### 2021-04-21

###conda activate torch 
###  2021-04-01
python ./bin/EAGERER.py  eg.list 
